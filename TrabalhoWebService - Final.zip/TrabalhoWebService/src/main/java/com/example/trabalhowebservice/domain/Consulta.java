package com.example.trabalhowebservice.domain;

import com.example.trabalhowebservice.dto.ConsultaAgendaDTO;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.time.LocalDateTime;

public class Consulta {

    private int id;
    private int pacienteId;
    private int medicoId;
    private LocalDateTime dataHora;
    private String motivoCancelamento;

    public Consulta() {

    }

    public Consulta(int id, int pacienteId, int medicoId, LocalDateTime dataHora, String motivoCancelamento) {
        this.id = id;
        this.pacienteId = pacienteId;
        this.medicoId = medicoId;
        this.dataHora = dataHora;
        this.motivoCancelamento = motivoCancelamento;
    }

    public Consulta(ConsultaAgendaDTO consultaDTO) {
        this.pacienteId = consultaDTO.getPacienteId();
        this.medicoId = consultaDTO.getMedicoId();
        this.dataHora = consultaDTO.getDataHora();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPacienteId() {
        return pacienteId;
    }

    public void setPacienteId(int pacienteId) {
        this.pacienteId = pacienteId;
    }

    public int getMedicoId() {
        return medicoId;
    }

    public void setMedicoId(int medicoId) {
        this.medicoId = medicoId;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getMotivoCancelamento() {
        return motivoCancelamento;
    }

    public void setMotivoCancelamento(String motivoCancelamento) {
        this.motivoCancelamento = motivoCancelamento;
    }
}
