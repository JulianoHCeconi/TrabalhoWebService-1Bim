package com.example.trabalhowebservice.dto;

import com.example.trabalhowebservice.domain.Medico;

public class MedicoDeleteRequestDTO{

    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
