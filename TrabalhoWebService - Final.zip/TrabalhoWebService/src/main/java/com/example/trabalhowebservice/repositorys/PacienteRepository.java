package com.example.trabalhowebservice.repositorys;

import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.domain.Paciente;
import com.example.trabalhowebservice.infraestructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class PacienteRepository {

    private static final String INSERT = "insert into paciente (nome, email, telefone, cpf," +
            "logradouro, numero, complemento, bairro, cidade, uf, cep) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE = "update paciente set nome = ?, telefone = ?, logradouro = ?," +
                                "numero = ?, complemento = ?, bairro = ?, cidade = ?, uf = ?, cep = ? where id = ?";

    private static final String DELETE = "update paciente SET ativo = false where id = ?";

    private static final String FIND_ALL = "SELECT nome, email, cpf FROM paciente ORDER BY nome ASC";


    public Paciente inserir(Paciente paciente) throws SQLException, NamingException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{

            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, paciente.getNome());
            pstmt.setString(2, paciente.getEmail());
            pstmt.setString(3, paciente.getTelefone());
            pstmt.setString(4, paciente.getCpf());
            pstmt.setString(5, paciente.getLogradouro());
            pstmt.setInt(6, paciente.getNumero());
            pstmt.setString(7, paciente.getComplemento());
            pstmt.setString(8, paciente.getBairro());
            pstmt.setString(9, paciente.getCidade());
            pstmt.setString(10, paciente.getUf());
            pstmt.setString(11, paciente.getCep());
            pstmt.executeUpdate();

            rs = pstmt.getGeneratedKeys();
            rs.next();
            paciente.setId(rs.getInt(1));

        }finally{
            if(pstmt != null) pstmt.close();
            if(rs != null) rs.close();
            if(conn != null) conn.close();
        }

        return paciente;

    }

    public void atualizar(Paciente paciente) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(UPDATE);
            pstmt.setString(1, paciente.getNome());
            pstmt.setString(2, paciente.getTelefone());
            pstmt.setString(3, paciente.getLogradouro());
            pstmt.setInt(4, paciente.getNumero());
            pstmt.setString(5, paciente.getComplemento());
            pstmt.setString(6, paciente.getBairro());
            pstmt.setString(7, paciente.getCidade());
            pstmt.setString(8, paciente.getUf());
            pstmt.setString(9, paciente.getCep());
            pstmt.setInt(10, paciente.getId());
            pstmt.executeUpdate();

        }finally {
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
        }
    }

    public List<Paciente> listaPaciente() throws SQLException, NamingException {
        List<Paciente> pacientes = new ArrayList<Paciente>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{

            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            while(rs.next()){
                Paciente paciente = new Paciente();
                paciente.setNome(rs.getString(1));
                paciente.setEmail(rs.getString(2));
                paciente.setCpf(rs.getString(3));
                pacientes.add(paciente);

            }
        }finally {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return pacientes;

    }

    public void excluir(int id) throws SQLException, NamingException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        }finally {
            if(pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

    }

}
