package com.example.trabalhowebservice.services;

import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.domain.Paciente;
import com.example.trabalhowebservice.dto.PacienteUpdateRequestDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import com.example.trabalhowebservice.repositorys.PacienteRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public class PacienteService {

    private PacienteRepository pacienteRepository;

    public PacienteService() {
        pacienteRepository = new PacienteRepository();
    }

    public Paciente inserir(Paciente paciente) throws BusinessException{

        //Valida nome
        if(paciente.getNome() == null || paciente.getNome().isEmpty()){
            throw new BusinessException("O nome do paciente é obrigatório!");
        }

        if(paciente.getNome().length() > 100){
            throw new BusinessException("O nome do paciente deve ter no maximo 100 caracteres!");
        }

        //Valida e-mail
        if(paciente.getEmail() == null || paciente.getEmail().isEmpty()){
            throw new BusinessException("E-mail do paciente é obrigatório!");
        }

        if(paciente.getEmail().length() > 50){
            throw new BusinessException("O e-mail deve ter no maximo 50 caracteres!");
        }

        //Valida telefone
        if(paciente.getTelefone() == null || paciente.getTelefone().isEmpty()){
            throw new BusinessException("Número de telefone é obrigatório!");
        }

        if(paciente.getTelefone().length() > 11){
            throw new BusinessException("O numero do telefone deve ter no maxio 11 caracteres!");
        }

        //valida cpf
        if(paciente.getCpf() == null || paciente.getCpf().isEmpty()){
            throw new BusinessException("O CPF do paciente é obrigatório!");
        }

        if(paciente.getCpf().length() != 11){
            throw new BusinessException("O CPF deve ter 11 caracteres!");
        }

        //Valida logradouro
        if(paciente.getLogradouro() == null || paciente.getLogradouro().isEmpty()){
            throw new BusinessException("O logradouro é obrigatório");
        }

        if(paciente.getLogradouro().length() > 100){
            throw new BusinessException("O logradouro deve ter no maximo 100 caracteres");
        }

        //Valida bairro
        if(paciente.getBairro() == null || paciente.getBairro().isEmpty()){
            throw new BusinessException("O bairro é obrigatório!");
        }

        if(paciente.getBairro().length() > 100){
            throw new BusinessException("O bairro deve ter no maximo 100 caracteres!");
        }

        //valida cidade
        if(paciente.getCidade() == null || paciente.getCidade().isEmpty()){
            throw new BusinessException("A cidade do paciente é obrigatória!");
        }

        if(paciente.getCidade().length() > 100){
            throw new BusinessException("A cidade deve ter no máximo 100 caracteres!");
        }

        //valida uf
        if(paciente.getUf() == null || paciente.getUf().isEmpty()){
            throw new BusinessException("UF do paciente é obrigatória!");
        }

        if(paciente.getUf().length() != 2){
            throw new BusinessException("A UF deve ter 2 caracteres!");
        }

        //valida cep
        if(paciente.getCep() == null || paciente.getCep().isEmpty()){
            throw new BusinessException("O CEP é obrigatório!");
        }

        if(paciente.getCep().length() != 9) {
            throw new BusinessException("O CEP deve ter 9 caracteres!");
        }

        try{
            pacienteRepository.inserir(paciente);
            return paciente;
        }catch (Exception e){
            e.printStackTrace();
            throw new BusinessException("Erro ao inserir paciente!");
        }

    }

    public Paciente atualizar(PacienteUpdateRequestDTO dto) throws BusinessException{

        if(dto.getNome() == null || dto.getNome().isEmpty()){
            throw new BusinessException("O nome é obrigatório!");
        }

        if(dto.getTelefone() == null || dto.getTelefone().isEmpty()){
            throw new BusinessException("O telefone do dto é obrigatório");
        }

        if(dto.getTelefone().length() > 11){
            throw new BusinessException("O telefone deve ter 11 caracteres");
        }

        if(dto.getLogradouro() == null || dto.getLogradouro().isEmpty()){
            throw new BusinessException("O logradouro é obrigatório!");
        }

        if(dto.getLogradouro().length() > 100){
            throw new BusinessException("O logradouro deve ter no maximo 100 caracteres!");
        }

        if(dto.getNumero() == String.valueOf(0)){
            throw new BusinessException("O numero não pode ser nulo");
        }

        if(dto.getComplemento() == null || dto.getComplemento().isEmpty()){
            throw new BusinessException("O complemento é obrigatório!");
        }

        if(dto.getComplemento().length() > 100){
            throw new BusinessException("O complemento não pode ultrapassar que 100 caracteres!");
        }

        if(dto.getBairro() == null || dto.getBairro().isEmpty()){
            throw new BusinessException("O bairro é obrigatório!");
        }

        if(dto.getBairro().length() > 100){
            throw new BusinessException("O bairro não pode ultrapassar que 100 caracteres!");
        }

        if(dto.getCidade() == null || dto.getCidade().isEmpty()){
            throw new BusinessException("Cidade é obrigatório");
        }

        if(dto.getCidade().length() > 100){
            throw new BusinessException("A cidade não pode ultrapassar que 100 caracteres!");
        }

        if(dto.getUf() == null || dto.getUf().isEmpty()){
            throw new BusinessException("O UF é obrigatório");
        }

        if(dto.getUf().length() > 2){
            throw new BusinessException("UF deve ter no máximo 2 caracteres!");
        }

        if(dto.getCep() == null || dto.getCep().isEmpty()){
            throw new BusinessException("CEP é obrigatório!");
        }

        if(dto.getCep().length() != 9){
            throw new BusinessException("CEP deve ter 9 caracteres!");
        }

        try{
            Paciente paciente = new Paciente(dto);
            pacienteRepository.atualizar(paciente);
            return paciente;
        }catch (Exception e){
            e.printStackTrace();
            throw new  BusinessException("Erro ao atualizar dto");
        }

    }

    public List<Paciente> listaPaciente() throws BusinessException {
        try{
            return pacienteRepository.listaPaciente();
        }catch (SQLException | NamingException e){
            e.printStackTrace();
            throw new BusinessException("Erro ao listar paciente!");
        }
    }

    public void excluir(int id) throws BusinessException{

        if(id <= 0){
            throw new BusinessException("O nome do médico é obrigatório para a exclusão!");
        }

        try{
            pacienteRepository.excluir(id);
        }catch (SQLException | NamingException e){
            e.printStackTrace();
            throw new BusinessException("Erro ao excluir paciente!");
        }

    }

}
