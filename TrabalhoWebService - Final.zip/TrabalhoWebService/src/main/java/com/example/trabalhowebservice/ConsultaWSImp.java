package com.example.trabalhowebservice;

import com.example.trabalhowebservice.domain.Consulta;
import com.example.trabalhowebservice.dto.ConsultaAgendaDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import com.example.trabalhowebservice.interfaces.ConsultaWS;
import com.example.trabalhowebservice.services.ConsultaService;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService (endpointInterface = "com.example.trabalhowebservice.interfaces.ConsultaWS")
public class ConsultaWSImp implements ConsultaWS {


    @Override
    public Consulta inserir(ConsultaAgendaDTO consultaDTO) throws BusinessException, SQLException, NamingException {
        Consulta consulta = new Consulta(consultaDTO);

        ConsultaService consultaService = new ConsultaService();
        return consultaService.inserir(consulta);
    }

    @Override
    public List<Consulta> buscaConsulta() throws BusinessException, SQLException, NamingException {
        ConsultaService consultaService = new ConsultaService();
        return consultaService.listaConsultas();
    }

    @Override
    public void cancelarConsulta(int id, String motivo) throws BusinessException, SQLException, NamingException {
        ConsultaService consultaService = new ConsultaService();
        consultaService.cancelaConsulta(id, motivo);
    }
}
