package com.example.trabalhowebservice.interfaces;

import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.domain.Paciente;
import com.example.trabalhowebservice.dto.MedicoInsertRequestDTO;
import com.example.trabalhowebservice.dto.MedicoUpdateRequestDTO;
import com.example.trabalhowebservice.dto.PacienteInsertRequestDTO;
import com.example.trabalhowebservice.dto.PacienteUpdateRequestDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService
public interface PacienteWS {

    @WebMethod
    Paciente inserir(PacienteInsertRequestDTO paciente) throws BusinessException, SQLException, NamingException;

    @WebMethod
    List<Paciente> listaPaciente() throws BusinessException, SQLException, NamingException;

    @WebMethod
    Paciente atualizar(PacienteUpdateRequestDTO paciente) throws BusinessException;

    @WebMethod
    void exlcuir(int id) throws BusinessException;

}
