package com.example.trabalhowebservice.interfaces;

import com.example.trabalhowebservice.domain.Consulta;
import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.dto.ConsultaAgendaDTO;
import com.example.trabalhowebservice.dto.ConsultaCancelamentoDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;

import javax.naming.NameAlreadyBoundException;
import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService
public interface ConsultaWS {

    @WebMethod
    Consulta inserir(ConsultaAgendaDTO consulta) throws BusinessException, SQLException, NamingException;

    @WebMethod
    List<Consulta> buscaConsulta() throws BusinessException, SQLException, NamingException;

    @WebMethod
    void cancelarConsulta(int id, String motivo) throws BusinessException, SQLException, NamingException;

}
