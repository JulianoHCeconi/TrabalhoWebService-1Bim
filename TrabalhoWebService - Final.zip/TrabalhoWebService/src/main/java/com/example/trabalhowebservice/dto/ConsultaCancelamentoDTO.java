package com.example.trabalhowebservice.dto;

public class ConsultaCancelamentoDTO {

    private Integer id;
    private String motivo;

    public ConsultaCancelamentoDTO() {

    }

    public ConsultaCancelamentoDTO(Integer id, String motivo) {
        this.id = id;
        this.motivo = motivo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
}
