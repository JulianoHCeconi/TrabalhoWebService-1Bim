package com.example.trabalhowebservice.repositorys;

import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.dto.MedicoUpdateRequestDTO;
import com.example.trabalhowebservice.infraestructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicoRepository {

    private static final String INSERT = "insert into medico (nome, email, telefone, crm," +
            "especialidade, logradouro, numero, complemento, bairro, ativo) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE = "update medico set nome = ?, telefone = ?, logradouro = ?," +
            "numero = ?, complemento = ?, bairro = ? where id = ?";

    private static final String DELETE = "update medico SET ativo = false where id = ?";

    private static final String FIND_ALL = "SELECT nome, email, crm, especialidade FROM medico " +
            "                               ORDER BY nome ASC";

    public Medico inserir(Medico medico) throws SQLException, NamingException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{

            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);

            pstmt.setString(1, medico.getNome());
            pstmt.setString(2, medico.getEmail());
            pstmt.setString(3, medico.getTelefone());
            pstmt.setString(4, medico.getCrm());
            pstmt.setString(5, medico.getEspecialidade());
            pstmt.setString(6, medico.getLogradouro());
            pstmt.setString(7, medico.getNumero());
            pstmt.setString(8, medico.getComplemento());
            pstmt.setString(9, medico.getBairro());
            pstmt.setBoolean(10,true);
            pstmt.executeUpdate();

            rs = pstmt.getGeneratedKeys();

            rs.next();
            medico.setId(rs.getInt(1));

        }finally{
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
            if (rs != null) rs.close();
        }

        return medico;

    }

    public List<Medico> buscarMedico() throws SQLException, NamingException {
        List<Medico> medicos = new ArrayList<Medico>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{

            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            while(rs.next()){
                Medico medico = new Medico();
                medico.setNome(rs.getString(1));
                medico.setEmail(rs.getString(2));
                medico.setCrm(rs.getString(3));
                medico.setEspecialidade(rs.getString(4));
                medicos.add(medico);

            }
        }finally {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return medicos;

    }

    public void atualizar(Medico medico) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(UPDATE);
            pstmt.setString(1, medico.getNome());
            pstmt.setString(2, medico.getTelefone());
            pstmt.setString(3, medico.getLogradouro());
            pstmt.setString(4, medico.getNumero());
            pstmt.setString(5, medico.getComplemento());
            pstmt.setString(6, medico.getBairro());
            pstmt.setInt(7,medico.getId());
            pstmt.executeUpdate();

        }finally {
            if(pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
    }

    public void excluir(int id) throws SQLException, NamingException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        }finally {
            if(pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

    }


}
