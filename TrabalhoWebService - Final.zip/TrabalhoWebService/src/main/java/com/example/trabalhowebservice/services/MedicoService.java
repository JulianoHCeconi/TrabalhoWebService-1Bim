package com.example.trabalhowebservice.services;

import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.dto.MedicoInsertRequestDTO;
import com.example.trabalhowebservice.dto.MedicoUpdateRequestDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import com.example.trabalhowebservice.repositorys.MedicoRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public class MedicoService {

    private MedicoRepository medicoRepository;

    public MedicoService() {
        medicoRepository = new MedicoRepository();
    }

    public Medico inserir(Medico medico) throws BusinessException, SQLException, NamingException {

        //Valida o nome
        if(medico.getNome() == null || medico.getNome().isEmpty()){
            throw new BusinessException("Nome do médico é obrigatório");
        }

        if(medico.getNome().length() > 100){
            throw new BusinessException("O nome do médico deve ter no máximo 100 caracteres");
        }

        //Valida o e-mail
        if(medico.getEmail() == null || medico.getEmail().isEmpty()){
            throw new BusinessException("O e-mail é obrigatório!");
        }

        if(medico.getEmail().length() > 50){
            throw new BusinessException("O e-mail deve ter no máximo 50 caracteres");
        }

        //Valida o número de telefone
        if(medico.getTelefone() == null || medico.getTelefone().isEmpty()){
            throw new BusinessException("O número de telefone é obrigatório!");
        }

        if(medico.getTelefone().length() > 11){
            throw new BusinessException("O número deve ter no máximo 11 caracteres");
        }

        //Valida o crm
        if(medico.getCrm() == null || medico.getCrm().isEmpty()){
            throw new BusinessException("O CRM é obrigatório");
        }

        if(medico.getCrm().length() > 20){
            throw new BusinessException("O CRM deve ter no máximo 20 caracteres");
        }


        //valida a especialidade
        if(medico.getEspecialidade() == null || medico.getEspecialidade().isEmpty()){
            throw new BusinessException("A especialidade é obrigatória");
        }


        //Valida o logradouro
        if(medico.getLogradouro() == null || medico.getLogradouro().isEmpty()){
            throw new BusinessException("Logradouro é obrigatório!");
        }

        if(medico.getLogradouro().length() > 100){
            throw new BusinessException("O logradouro não pode ultrapassar 100 caracteres");
        }

        //Valida o número
        if(medico.getNumero().length() > 5){
            throw new BusinessException("O número da casa deve ter no máximo 5 digitos");
        }

        //Valida o complemento
        if(medico.getComplemento().length() > 100){
            throw new BusinessException("O complemento dever ter no máximo 100 caracteres");
        }

        //Valida o bairro
        if(medico.getBairro() == null || medico.getBairro().isEmpty()){
            throw new BusinessException("O bairro é obrigatório");
        }

        if(medico.getBairro().length() > 100){
            throw new BusinessException("O bairro deve ter no máximo 100 caracteres");
        }

        try{
            return medicoRepository.inserir(medico);
        }catch (BusinessException e){
            e.printStackTrace();
            throw new BusinessException("Erro ao inserir medico!");
        }

    }

    public List<Medico> buscarMedico() throws BusinessException {
        try{
            return medicoRepository.buscarMedico();
        }catch (SQLException | NamingException e){
            e.printStackTrace();
            throw new BusinessException("Erro ao buscar medico!");
        }
    }

    public Medico atualizar(MedicoUpdateRequestDTO dto) throws BusinessException {

        if(dto.getNome() == null || dto.getNome().isEmpty()){
            throw new BusinessException("O nome do médico é obrigatório para a edição!");
        }

        if(dto.getNome().length() > 100){
            throw new BusinessException("O nome do médico deve ter no máximo 100 caracteres");
        }

        if(dto.getTelefone() == null || dto.getTelefone().isEmpty()){
            throw new BusinessException("O número de telefone é obrigatório para a edição!");
        }

        if(dto.getTelefone().length() > 11){
            throw new BusinessException("O número deve ter no máximo 11 caracteres");
        }

        if(dto.getLogradouro() == null || dto.getLogradouro().isEmpty()){
            throw new BusinessException("Logradouro é obrigatório!");
        }

        if(dto.getLogradouro().length() > 100){
            throw new BusinessException("O logradouro não pode ultrapassar 100 caracteres");
        }

        if(dto.getNumero().length() > 5){
            throw new BusinessException("O número da casa deve ter no máximo 5 digitos");
        }

        if(dto.getComplemento().length() > 100){
            throw new BusinessException("O complemento dever ter no máximo 100 caracteres");
        }

        if(dto.getBairro() == null || dto.getBairro().isEmpty()){
            throw new BusinessException("O bairro é obrigatório");
        }

        if(dto.getBairro().length() > 100){
            throw new BusinessException("O bairro deve ter no máximo 100 caracteres");
        }



        try{
            Medico medico = new Medico(dto);
            medicoRepository.atualizar(medico);
            return medico;
        }catch (Exception e){
            e.printStackTrace();
            throw new BusinessException("Erro ao atualizar dto!");
        }

    }

    public void excluir (int id) throws BusinessException{

        if(id == 0){
            throw new BusinessException("O nome do médico é obrigatório para a exclusão!");
        }

        try{
            medicoRepository.excluir(id);
        }catch (SQLException | NamingException e){
            e.printStackTrace();
            throw new BusinessException("Erro ao excluir medico!");
        }

    }


}
