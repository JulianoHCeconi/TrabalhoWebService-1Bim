package com.example.trabalhowebservice.repositorys;

import com.example.trabalhowebservice.domain.Consulta;
import com.example.trabalhowebservice.domain.Paciente;
import com.example.trabalhowebservice.infraestructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ConsultaRepository {

    private static final String INSERT = "insert into consulta (paciente_id, medico_id, data_hora) values (?,?,?)";
    private static final String FIND_ALL = "select id, paciente_id, medico_id, data_hora, motivo_cancelamento " +
            "                                   from consulta order by data_hora ASC";
    private static final String FIND_BY_ID = "select id, paciente_id, medico_id, data_hora, cancelada, motivo_cancelamento " +
            "from consulta where id = ?";
    private static final String CANCELA_CONSULTA = "update consulta set cancelada = true, motivo_cancelamento = ? where id = ?";
    private static final String CHECA_DISP_MEDICO = "select count(*) from consulta where medico_id = ? " +
            "                                           and data_hora = ? and cancelada = false";
    private static final String CHECA_CONSULTA_NO_DIA = "select count(*) from consulta where paciente_id = ? and " +
            "                                           date (data_hora) = ? and cancelada = false";
    private static final String ESCOLHE_MEDICO = "select m.id FROM medico m " +
            "where not exists (select 1 from consulta c where c.medico_id = m.id and c.data_hora = ? and c.cancelada = false) " +
            "and m.ativo = true " +
            "limit 1";;



    public Consulta inserir(Consulta consulta) throws SQLException, NamingException{

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{
            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, consulta.getPacienteId());
            pstmt.setInt(2, consulta.getMedicoId());
            pstmt.setTimestamp(3, Timestamp.valueOf(consulta.getDataHora()));
            pstmt.executeUpdate();

            rs = pstmt.getGeneratedKeys();
            rs.next();
            consulta.setId(rs.getInt(1));

        }finally {
            if(pstmt != null) pstmt.close();
            if(rs != null) rs.close();
            if(conn != null) conn.close();
        }

        return consulta;

    }

    public List<Consulta> buscaConsulta() throws SQLException, NamingException{
        List<Consulta> consultas = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            while(rs.next()){
                Consulta consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setPacienteId(rs.getInt("paciente_id"));
                consulta.setMedicoId(rs.getInt("medico_id"));
                consulta.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                consulta.setMotivoCancelamento(rs.getString("motivo_cancelamento"));
                consultas.add(consulta);
            }
        }finally {
            if(pstmt != null) pstmt.close();
            if(rs != null) rs.close();
            if(conn != null) conn.close();
        }

        return consultas;

    }

    public Consulta buscarPorId(Integer id) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Consulta consulta = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(FIND_BY_ID);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setPacienteId(rs.getInt("paciente_id"));
                consulta.setMedicoId(rs.getInt("medico_id"));
                consulta.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                consulta.setMotivoCancelamento(rs.getString("motivo_cancelamento"));
            }

        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return consulta;
    }

    public void cancelarConsulta(int id, String motivo) throws SQLException, NamingException{

        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(CANCELA_CONSULTA);
            pstmt.setString(1, motivo);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();

        }finally {
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
        }

    }

    public boolean verificaDispMedico(Integer medicoId, LocalDateTime dataHora) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(CHECA_DISP_MEDICO);
            pstmt.setInt(1, medicoId);
            pstmt.setTimestamp(2, Timestamp.valueOf(dataHora));
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return count == 0;
    }

    public boolean verificaConsultaNoDia(Integer pacienteId, LocalDateTime dataHora) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(CHECA_CONSULTA_NO_DIA);
            pstmt.setInt(1, pacienteId);
            pstmt.setDate(2, java.sql.Date.valueOf(dataHora.toLocalDate()));
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return count == 0;
    }

    public Integer medicoDisponivel(LocalDateTime dataHora) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Integer medicoId = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(ESCOLHE_MEDICO);
            pstmt.setTimestamp(1, Timestamp.valueOf(dataHora));
            rs = pstmt.executeQuery();
            if (rs.next()) {
                medicoId = rs.getInt("id");
            }
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return medicoId;
    }

}
