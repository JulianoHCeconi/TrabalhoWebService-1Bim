package com.example.trabalhowebservice.services;

import com.example.trabalhowebservice.domain.Consulta;
import com.example.trabalhowebservice.dto.ConsultaAgendaDTO;
import com.example.trabalhowebservice.dto.ConsultaCancelamentoDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import com.example.trabalhowebservice.repositorys.ConsultaRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class ConsultaService {

    private final ConsultaRepository consultaRepository;

    public ConsultaService() {
       this.consultaRepository = new ConsultaRepository();
    }

    public Consulta inserir(Consulta consulta) throws BusinessException, SQLException, NamingException{

        LocalDateTime agora = LocalDateTime.now();

        if(consulta.getPacienteId() == 0){
            throw new BusinessException("O ID do paciente é obrigatório");
        }

        if(consulta.getDataHora() == null){
            throw new BusinessException("A hora da consulta é obrigatório!");
        }

        if(consulta.getDataHora().isBefore(agora.plusMinutes(30))){
            throw new BusinessException("A consulta deve ser marcada com 30 minutos de antecedecia!");
        }

        if(consulta.getDataHora().getHour() < 7 || consulta.getDataHora().getHour() >= 19){
            throw new BusinessException("A clinica fica aberta entre 07:00 e 19:00!");
        }

        if (consulta.getMedicoId() == -1) {
            Integer medicoId = consultaRepository.medicoDisponivel(consulta.getDataHora());
            if (medicoId == null) {
                throw new BusinessException("Não há médicos disponíveis para esse horário");
            }
            consulta.setMedicoId(medicoId);
        }

        if (!consultaRepository.verificaDispMedico(consulta.getMedicoId(), consulta.getDataHora())) {
            throw new BusinessException("O médico selecionado já tem consulta nesse horário");
        }

        if (!consultaRepository.verificaConsultaNoDia(consulta.getPacienteId(), consulta.getDataHora())) {
            throw new BusinessException("O paciente já tem uma consulta agendada para esta data!");
        }

        consulta.setPacienteId(consulta.getPacienteId());
        consulta.setDataHora(consulta.getDataHora());
        consulta.setMedicoId(consulta.getMedicoId());

        return consultaRepository.inserir(consulta);
    }

    public void cancelaConsulta(int id, String motivo) throws BusinessException, SQLException, NamingException {

        if (id == 0) {
            throw new BusinessException("ID da consulta é obrigatório");
        }

        if (motivo == null || motivo.isEmpty()) {
            throw new BusinessException("O motivo do cancelamento da consulta é obrigatório");
        }

        Consulta consulta = consultaRepository.buscarPorId(id);

        if (consulta == null) {
            throw new BusinessException("Consulta não foi encontrada!");
        }

        LocalDateTime agora = LocalDateTime.now();
        if (ChronoUnit.HOURS.between(agora, consulta.getDataHora()) < 24) {
            throw new BusinessException("A consulta deve ser cancelada com 24 horas de antecedência");
        }

        consultaRepository.cancelarConsulta(id, motivo);
    }

    public List<Consulta> listaConsultas() throws SQLException, NamingException{
        return consultaRepository.buscaConsulta();
    }


}
