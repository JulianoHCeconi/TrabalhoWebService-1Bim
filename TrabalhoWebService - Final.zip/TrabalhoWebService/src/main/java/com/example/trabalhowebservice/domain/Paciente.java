package com.example.trabalhowebservice.domain;

import com.example.trabalhowebservice.dto.PacienteInsertRequestDTO;
import com.example.trabalhowebservice.dto.PacienteUpdateRequestDTO;

public class Paciente {

    private int id;
    private String nome;
    private String email;
    private String telefone;
    private String cpf;
    private String logradouro;
    private int numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String uf;
    private String cep;

    public Paciente(PacienteInsertRequestDTO pacienteDTO) {
        this.id = pacienteDTO.getId();
        this.nome = pacienteDTO.getNome();
        this.email = pacienteDTO.getEmail();
        this.telefone = pacienteDTO.getTelefone();
        this.cpf = pacienteDTO.getCpf();
        this.logradouro = pacienteDTO.getLogradouro();
        this.numero = Integer.parseInt(pacienteDTO.getNumero());
        this.complemento = pacienteDTO.getComplemento();
        this.bairro = pacienteDTO.getBairro();
        this.cidade = pacienteDTO.getCidade();
        this.uf = pacienteDTO.getUf();
        this.cep = pacienteDTO.getCep();
    }

    public Paciente(PacienteUpdateRequestDTO pacienteDTO) {
        this.id = pacienteDTO.getId();
        this.nome = pacienteDTO.getNome();
        this.telefone = pacienteDTO.getTelefone();
        this.logradouro = pacienteDTO.getLogradouro();
        this.numero = Integer.parseInt(pacienteDTO.getNumero());
        this.complemento = pacienteDTO.getComplemento();
        this.bairro = pacienteDTO.getBairro();
        this.cidade = pacienteDTO.getCidade();
        this.uf = pacienteDTO.getUf();
        this.cep = pacienteDTO.getCep();
    }

    public Paciente() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }
}
