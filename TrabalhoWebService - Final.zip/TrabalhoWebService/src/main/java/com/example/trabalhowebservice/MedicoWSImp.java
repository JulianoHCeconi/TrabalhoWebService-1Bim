package com.example.trabalhowebservice;

import com.example.trabalhowebservice.domain.Medico;
import com.example.trabalhowebservice.dto.MedicoInsertRequestDTO;
import com.example.trabalhowebservice.dto.MedicoUpdateRequestDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import com.example.trabalhowebservice.interfaces.MedicoWS;
import com.example.trabalhowebservice.services.MedicoService;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService(endpointInterface = "com.example.trabalhowebservice.interfaces.MedicoWS")
public class MedicoWSImp implements MedicoWS {


    @Override
    public Medico inserir(MedicoInsertRequestDTO medicoDTO) throws BusinessException, SQLException, NamingException {
        Medico medico = new Medico(medicoDTO);

        MedicoService medicoService = new MedicoService();
        return medicoService.inserir(medico);
    }

    @Override
    public List<Medico> buscarTodos() throws BusinessException {
        MedicoService medicoService = new MedicoService();
        return medicoService.buscarMedico();
    }

    @Override
    public Medico atualizar(MedicoUpdateRequestDTO medico) throws BusinessException {
        MedicoService medicoService = new MedicoService();
        return medicoService.atualizar(medico);
    }

    @Override
    public void exlcuir(int id) throws BusinessException {
        MedicoService medicoService = new MedicoService();
        medicoService.excluir(id);
    }

}
