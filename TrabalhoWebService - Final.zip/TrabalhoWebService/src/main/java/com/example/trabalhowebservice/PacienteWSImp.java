package com.example.trabalhowebservice;

import com.example.trabalhowebservice.domain.Paciente;
import com.example.trabalhowebservice.dto.PacienteInsertRequestDTO;
import com.example.trabalhowebservice.dto.PacienteUpdateRequestDTO;
import com.example.trabalhowebservice.exceptions.BusinessException;
import com.example.trabalhowebservice.interfaces.PacienteWS;
import com.example.trabalhowebservice.services.PacienteService;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService (endpointInterface = "com.example.trabalhowebservice.interfaces.PacienteWS")
public class PacienteWSImp implements PacienteWS {

    @Override
    public Paciente inserir(PacienteInsertRequestDTO pacienteDTO) throws BusinessException {
        Paciente paciente = new Paciente(pacienteDTO);

        PacienteService pacienteService = new PacienteService();
        return pacienteService.inserir(paciente);
    }

    @Override
    public List<Paciente> listaPaciente() throws BusinessException {
        PacienteService pacienteService = new PacienteService();
        return pacienteService.listaPaciente();
    }

    @Override
    public Paciente atualizar(PacienteUpdateRequestDTO paciente) throws BusinessException {
        PacienteService pacienteService = new PacienteService();
        return pacienteService.atualizar(paciente);
    }

    @Override
    public void exlcuir(int id) throws BusinessException {
        PacienteService pacienteService = new PacienteService();
        pacienteService.excluir(id);
    }
}
